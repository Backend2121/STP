document.addEventListener("stp:probe", (event) => {
  let names = [];
  try {
    names = JSON.parse(event.detail);
  } catch (err) {}

  if (names.some((name) => typeof window[name] !== "undefined")) {
    event.preventDefault();
  }
});
