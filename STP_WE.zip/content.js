(function () {
  const CAPTURE_MARKER = "stp-capture";
  const INITIAL_GRACE_MS = 2000;

  function isMarkedByScript() {
    return location.hash.includes(CAPTURE_MARKER);
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  const KNOWN_CHALLENGE_GLOBALS = [
    "_cf_chl_opt", // Cloudflare
    "bmak", // Akamai Bot Manager
    "_pxAppId", // PerimeterX / HUMAN
    "AwsWafIntegration", // AWS WAF challenge
    "KPSDK", // Kasada
  ];

  const KNOWN_CHALLENGE_SCRIPT_HOSTS = [
    "challenges.cloudflare.com",
    "captcha-delivery.com", // DataDome
    "px-cloud.net", // PerimeterX / HUMAN
    "kasada.io",
    "awswaf.com",
  ];

  const CHALLENGE_TEXT_PATTERNS = [
    /checking your browser/i,
    /verifying you are human/i,
    /verify you are human/i,
    /this may take a few seconds/i,
    /diamwall/i
  ];

  function hasKnownChallengeGlobal() {
    try {
      if (typeof window.wrappedJSObject !== "undefined") {
        return KNOWN_CHALLENGE_GLOBALS.some((name) => typeof window.wrappedJSObject[name] !== "undefined");
      }

      return !document.dispatchEvent(
        new CustomEvent("stp:probe", {
          cancelable: true,
          detail: JSON.stringify(KNOWN_CHALLENGE_GLOBALS),
        })
      );
    } catch (err) {
      return false;
    }
  }

  function hasKnownChallengeScript() {
    try {
      return Array.from(document.scripts).some(
        (script) => script.src && KNOWN_CHALLENGE_SCRIPT_HOSTS.some((host) => script.src.includes(host))
      );
    } catch (err) {
      return false;
    }
  }

  function isAntiBotChallenge() {
    const title = document.title || "";
    const bodyText = (document.body && document.body.textContent) || "";

    const hasKnownSignature =
      title.startsWith("Just a moment") ||
      !!document.querySelector("#challenge-running") ||
      !!document.querySelector("#cf-challenge-running") ||
      !!document.querySelector(".cf-browser-verification") ||
      !!document.getElementById("challenge-form") ||
      hasKnownChallengeGlobal() ||
      hasKnownChallengeScript();

    const hasChallengeText = CHALLENGE_TEXT_PATTERNS.some((pattern) => pattern.test(bodyText));

    return hasKnownSignature || hasChallengeText;
  }

  function waitForAntiBotChallenge({
    timeoutMs = 10 * 60 * 1000,
    pollMs = 300,
    heartbeatMs = 15000,
  } = {}) {
    return new Promise((resolve) => {
      if (!isAntiBotChallenge()) {
        resolve();
        return;
      }

      console.log("STP Extension: anti-bot check detected, waiting for it to clear...");

      let settled = false;
      const finish = () => {
        if (settled) return;
        settled = true;
        observer.disconnect();
        clearInterval(poller);
        clearInterval(heartbeat);
        clearTimeout(timer);
        resolve();
      };

      const observer = new MutationObserver(() => {
        if (!isAntiBotChallenge()) finish();
      });
      observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true,
        characterData: true,
      });

      const poller = setInterval(() => {
        if (!isAntiBotChallenge()) finish();
      }, pollMs);

      const heartbeat = setInterval(() => {
        console.log("STP Extension: still waiting on the anti-bot check to clear...");
      }, heartbeatMs);

      const timer = setTimeout(() => {
        console.warn("STP Extension: gave up waiting for the anti-bot check to clear");
        finish();
      }, timeoutMs);
    });
  }

  function getShadowRoot(element) {
    try {
      if (browser.dom?.openOrClosedShadowRoot) return browser.dom.openOrClosedShadowRoot(element);
      return element.openOrClosedShadowRoot || element.shadowRoot;
    } catch (err) {
      return element.shadowRoot;
    }
  }

  function collectShadowRoots(node, acc = []) {
    const shadowRoot = node.nodeType === Node.ELEMENT_NODE ? getShadowRoot(node) : null;
    if (shadowRoot) {
      acc.push(shadowRoot);
      collectShadowRoots(shadowRoot, acc);
    }
    for (const child of node.children || []) {
      collectShadowRoots(child, acc);
    }
    return acc;
  }

  function captureFullHtml() {
    const root = document.documentElement;

    if (typeof root.getHTML === "function") {
      try {
        const shadowRoots = collectShadowRoots(root);
        return root.getHTML({ serializableShadowRoots: true, shadowRoots });
      } catch (err) {
        console.warn("STP Extension: getHTML with shadow roots failed, falling back to outerHTML", err);
      }
    }

    return root.outerHTML;
  }

  async function sendFullPage() {
    if (!isMarkedByScript()) return;

    await sleep(INITIAL_GRACE_MS);
    await waitForAntiBotChallenge();
    if (isAntiBotChallenge()) return;

    browser.runtime
      .sendMessage({
        type: "PAGE_LOADED",
        url: location.href,
        html: captureFullHtml(),
      })
      .catch((err) => console.error("STP Extension: failed to send page HTML", err));
  }

  if (document.readyState === "complete") {
    sendFullPage();
  } else {
    window.addEventListener("load", sendFullPage, { once: true });
  }
})();
