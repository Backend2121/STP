#!/bin/sh
set -e
cd "$(dirname "$0")"

rm -rf dist/chrome
mkdir -p dist/chrome

cp content.js background.js page-probe.js options.html options.js dist/chrome/
cp -R icons dist/chrome/icons

node -e '
const fs = require("fs");
const { version } = JSON.parse(fs.readFileSync("manifest.json", "utf8"));
const manifest = JSON.parse(fs.readFileSync("manifest.chrome.json", "utf8"));
manifest.version = version;
fs.writeFileSync("dist/chrome/manifest.json", JSON.stringify(manifest, null, 2) + "\n");
'

echo "Built dist/chrome (version $(node -p 'require("./dist/chrome/manifest.json").version'))"
