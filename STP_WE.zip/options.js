const DEFAULT_API_HOST = "127.0.0.1:8080";

const apiHostInput = document.getElementById("apiHost");
const status = document.getElementById("status");

async function restore() {
  const { apiHost } = await browser.storage.local.get("apiHost");
  apiHostInput.value = apiHost || DEFAULT_API_HOST;
}

async function save() {
  await browser.storage.local.set({
    apiHost: apiHostInput.value.trim(),
  });
  status.textContent = "Saved!";
  setTimeout(() => (status.textContent = ""), 1500);
}

document.addEventListener("DOMContentLoaded", restore);
document.getElementById("save").addEventListener("click", save);
