const DEFAULT_API_HOST = "127.0.0.1:8080";
const ENDPOINT_PATH = "/api/eb";

async function getApiHost() {
  const { apiHost } = await browser.storage.local.get("apiHost");
  return (apiHost || DEFAULT_API_HOST).trim();
}

browser.runtime.onMessage.addListener(async (message, sender) => {
  if (!message || message.type !== "PAGE_LOADED") return;

  const host = await getApiHost();
  const url = `http://${host}${ENDPOINT_PATH}`;

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: message.url, html: message.html }),
    });

    if (!response.ok) {
      console.error(`STP Extension: API responded with status ${response.status} (${url})`);
    } else {
      const res = await response.json().catch(() => null);
      console.log("STP Extension: delivered OK, response:", res);

      if (sender.tab && sender.tab.id !== undefined) {
        browser.tabs
          .remove(sender.tab.id)
          .catch((err) => console.error("STP Extension: failed to close tab", err));
      }
    }
  } catch (err) {
    console.error("STP Extension: failed to reach API at", url, err);
  }
});
